<?php
class ModelExtensionApiApi extends Model {
	public function edit(&$data) {
		return $data;
	}
}